<?php

class backend_compatConfiguration extends sfApplicationConfiguration
{
  public function configure()
  {
  }
}
