<?php

class myPluginsSfAutoloadPluginModulesAutoloadPluginLibClass
{
  static public function ping()
  {
    return 'pong';
  }
}
