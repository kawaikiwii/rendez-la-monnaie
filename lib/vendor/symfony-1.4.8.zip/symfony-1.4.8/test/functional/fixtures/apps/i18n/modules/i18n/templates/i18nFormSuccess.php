<form action="<?php echo url_for('i18n/i18nForm') ?>" method="post">
<table>
  <?php echo $form ?>
  <tr>
    <td><input type="submit" value="Submit" /></td>
  </tr>
</table>
</form>